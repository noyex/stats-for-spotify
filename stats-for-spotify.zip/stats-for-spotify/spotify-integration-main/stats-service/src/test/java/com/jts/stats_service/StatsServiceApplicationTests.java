package com.jts.stats_service;

import org.testng.annotations.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class StatsServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}

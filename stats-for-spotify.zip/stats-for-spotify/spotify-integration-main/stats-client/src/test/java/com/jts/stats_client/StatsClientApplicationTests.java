package com.jts.stats_client;

import org.testng.annotations.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class StatsClientApplicationTests {

	@Test
	void contextLoads() {
	}

}

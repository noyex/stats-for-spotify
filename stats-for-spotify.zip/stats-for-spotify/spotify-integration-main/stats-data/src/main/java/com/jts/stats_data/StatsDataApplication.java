package com.jts.stats_data;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class StatsDataApplication {

	public static void main(String[] args) {
		SpringApplication.run(StatsDataApplication.class, args);
	}

}

package com.jts.stats_api;

import org.testng.annotations.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class StatsApiApplicationTests {

	@Test
	void contextLoads() {
	}

}
